//
//  CEENavigationViewController.h
//  CEECountdown
//
//  Created by Tony L on 7/7/16.
//  Copyright © 2016 com.jiemo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CEENavigationViewController : UINavigationController

@end
