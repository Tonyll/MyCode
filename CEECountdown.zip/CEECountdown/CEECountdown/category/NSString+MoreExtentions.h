//
//  NSString+MoreExtentions.h
//  UI2-微博
//
//  Created by hegf on 15/8/24.
//  Copyright (c) 2015年 hegf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (MoreExtentions)



-(BOOL)validatePhoneNumber;
@end
