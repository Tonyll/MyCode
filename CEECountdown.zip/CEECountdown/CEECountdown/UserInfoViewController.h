//
//  UserInfoViewController.h
//  CEECountdown
//
//  Created by Tony L on 7/14/16.
//  Copyright © 2016 com.jiemo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserModel.h"

@interface UserInfoViewController : UIViewController

@property (strong, nonatomic) UserModel *userInfo;

@end
