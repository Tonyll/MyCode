//
//  UserModel.h
//  CEECountdown
//
//  Created by Tony L on 7/14/16.
//  Copyright © 2016 com.jiemo. All rights reserved.
//

@interface UserModel : NSObject

//@property (strong, nonatomic) NSString *userName;
//@property (strong, nonatomic) NSString *password;

@property (strong, nonatomic) NSString *birthday;
@property (strong, nonatomic) NSString *imageUrl;
@property (strong, nonatomic) NSString *nickName;
@property (strong, nonatomic) NSString *sex;
@property (strong, nonatomic) NSString *hometown;
@property (strong, nonatomic) NSString *favorite;
@property (strong, nonatomic) NSString *qq;

@property (strong, nonatomic) NSString *userMobileNum;

@property (strong, nonatomic) NSString *userId;

@end
