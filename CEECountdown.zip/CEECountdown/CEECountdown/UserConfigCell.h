//
//  UserConfigCell.h
//  jiemoquan
//
//  Created by zangzhenzhao on 15/5/8.
//  Copyright (c) 2015年 IvanMacAir. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserConfigCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *headLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headImage;

@end
