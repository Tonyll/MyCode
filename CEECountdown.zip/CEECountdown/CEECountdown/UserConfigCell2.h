//
//  UserConfigCel2l.h
//  jiemoquan
//
//  Created by zangzhenzhao on 15/5/8.
//  Copyright (c) 2015年 IvanMacAir. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserConfigCell2 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *quiteLabel;

@end
