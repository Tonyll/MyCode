//
//  UserConfigCel1l.m
//  jiemoquan
//
//  Created by zangzhenzhao on 15/5/8.
//  Copyright (c) 2015年 IvanMacAir. All rights reserved.
//

#import "UserConfigCell1.h"

@implementation UserConfigCell1

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
