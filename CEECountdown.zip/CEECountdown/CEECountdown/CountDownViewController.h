//
//  CountDownViewController.h
//  CEECountdown
//
//  Created by Tony L on 7/7/16.
//  Copyright © 2016 com.jiemo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CountDownViewController : BaseViewController

/**
 *  高考时间
 */
@property (nonatomic, strong) NSString *destinationTimeStr;

@end
